![logo D2T-Plugin](https://github.com/anjakammer/data2table/blob/master/d2t_logo.png)

A Wordpress-Plugin for creating database tables and handling CRUD operations

This Wordpress Plugin provides the service to create database tables, 
without IT-Knowledge using the UI or importing data from .csv files.
Furthermore a widget can be used, to create a customized 
Wordpress content pages out of these custom database table values.

## Features
You find a [list of features here] (https://github.com/anjakammer/data2table/labels/Feature)

## Ressources and Libraries
- [Wordpress Plugin Boilerplate] (http://wppb.io/)

## How to install the D2T Plugin
1. Install a WebServer, like [XAMPP](https://www.apachefriends.org/download.html)
2. [Install Wordpress](https://premium.wpmudev.org/blog/setting-up-xampp)
3. Download the Plugin-Package from GitHub