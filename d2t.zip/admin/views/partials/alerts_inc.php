<div class="alert alert-success" role="alert" style="display: none;">
	<strong>Well done! </strong><span class="message"></span>
</div>
<div class="alert alert-info" role="alert" style="display: none;">
	<strong>Heads up! </strong><span class="message"></span>
</div>
<div class="alert alert-warning" role="alert" style="display: none;">
	<strong>Warning! </strong><span class="message"></span>
</div>
<div class="alert alert-danger" role="alert" style="display: none;">
	<strong>Oh snap! </strong><span class="message"></span>
</div>